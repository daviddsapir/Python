"""--------------------------------------------------------

file: ex5_David_Sapir_Shimson_Polak.py

Written by:
David Sapir, id = 208917351, login = davidsa
Shimson Polak, id = 315605642, login = shimshonpo

Program Description:
The first function finds for all the 30 largest cities in
the US their postal code.

The second function finds Files that have been successfully
completed and writes them into an external file.

--------------------------------------------------------"""
import re


# ------------------------ Question 1 ---------------------------
def save_largest_cities_postal():
    """Save in "largest_cities_postal_codes.txt"
     the largest cities with their postal numbers"""
    largest_cities = open("2019_largest_cities.txt", "r")
    us_postal_codes = open("us_postal_codes.csv", "r")
    largest_cities_codes = open("largest_cities_postal_codes.txt", "w")

    cities = set()

    # Find the cities in file "2019_largest_cities"
    for i in largest_cities:
        city = re.search(r"(\d*).(([A-Z][a-z]* [A-Z][a-z]*)|([A-Z][a-z]*))[A-Z]", i)
        if city:
            cities.add(city.group(2))

    # Compare the cities found with us_postal_codes cities"
    checked_cities = set()
    for postal_code in us_postal_codes:
        code = re.search(r"(\d*).(\w* ?\w*).(\w* ?\w*)", postal_code)

        city = code.group(2)
        if city not in checked_cities and city in cities:
            largest_cities_codes.write(city + "\t" + code.group(1) + "\n")
            checked_cities.add(city)

    largest_cities_codes.close()


# ------------------------ Question 2 ---------------------------
def save_successful_runs():
    "Save in file 'successfull.txt' the successful runs witout comments"
    compile_status = open("atoms2.log", "r")
    successful_run = open("successfull.txt", "w")

    # Runs over the input file and check which of the program had
    # a successful run status. If the file had a successful run, we
    # print to an external file the file number and it's name.
    for status in compile_status:
        run_status = re.search("(\w*.dat.) \d*.\d* CPU SECONDS.$", status)
        file_num = re.search("RUN (\d+) COMPLETED.", status)
        if run_status:
            successful_run.write(file_num.group(1) + "\t"
                                 + run_status.group(1) + '\n')

    successful_run.close()


def choose_operation():
    operation = int(input("insert the following: 1 - save output file of largest cities postal codes\n\
                      2 - save the output of successful runs witout comments.\n"))
    if operation == 1:
        save_largest_cities_postal()
    elif operation == 2:
        save_successful_runs()


choose_operation()
